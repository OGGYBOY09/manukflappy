﻿{
	"version": 1709166854,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/background-sheet0.png",
		"images/frame2cremovebgpreview-sheet0.png",
		"images/bawah-sheet0.png",
		"images/atas-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}